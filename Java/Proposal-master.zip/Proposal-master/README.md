# Descripción del proyecto
  Proyecto en java para evitar la friendzone y notificaciones personalizadas.
# Pre-requisitos
  Tener instalado Java.
# Uso
  # Para su proyecto:
    1.- Para generar el JAR de su proyecto deben dar click derecho -> Clean and Build.
    2.- Se generará una carpeta con el nombre "dist", dentro de esa carpeta está el JAR junto con las librerías por separado, si quieren enviarlo deben comprimir esa carpeta       "dist" junto con el archivo JAR y sus librerías.
    3.- Si quieren que se generar un JAR todo en uno (con las librerías ya incluidas dentro del JAR) vayan aquí: https://www.youtube.com/watch?v=TK-cNN2lwS0
  # Para este proyecto:
    Descargar el archivo Proposal.jar ([JAR] = Java Archive) dentro de la carpeta Proposal y enviarlo a la persona, debería ejecutarse sin problemas si tiene instalado JAVA.
# Librerías utilizadas
  https://github.com/RojeruSan/RSNotify-v1.0 (RojeruSan)
# Diccionario proyecto
  JAR: Abreviatura de Java Archive, suele contener varios archivos JAVA y metadatos de manera sintetizada y comprimida. Es el archivo que se genera al compilar tu código Java.
